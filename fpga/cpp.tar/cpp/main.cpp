#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include "bdbmpcie.h"
#include "dmasplitter.h"


int main(int argc, char** argv) {
	BdbmPcie* pcie = BdbmPcie::getInstance();

	//unsigned int d = pcie->readWord(0);
	//printf( "Magic: %x\n", d );
	//fflush(stdout);

	//pcie->userWriteWord(0, 0xdeadbeef);
	//pcie->userWriteWord(4, 0xcafef00d);
	sleep(10);
	//while(1) {
		//int input;
		//printf("Press r:");
		//scanf("%d", &input);	
		//if (input == 10) {
			for ( int i = 0; i < 8; i++ ) {
				printf( "%d, ", pcie->userReadWord(i*4) );
			}
			printf("\n");
		//}
		
	//}
	return 0;
}
